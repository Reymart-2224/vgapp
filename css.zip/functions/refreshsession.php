<?php

session_start();

echo "Session Refreshed";