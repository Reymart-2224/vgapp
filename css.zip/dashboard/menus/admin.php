

            <!-- Nav Item - Pages Collapse Menu -->
			
			
            <li class="nav-item <?php if($_GET['m']=='churches'){ echo 'active'; }?>">
                 <a class="nav-link" href="?m=churches">
                    <img src="../img/vglogo.png" style="width:10%">
                    <span>Victory Churches</span></a>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item <?php if($_GET['m']=='pastors'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=pastors">
                              <i class="fas fa-fw fa-users"></i>
                    <span>Pastors</span></a>
            </li>
			   <li class="nav-item <?php if($_GET['m']=='leaders'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=leaders">
                              <i class="fas fa-fw fa-users"></i>
                    <span>VG Leaders</span></a>
            </li>
			
			 
			
			
			 <li class="nav-item <?php if($_GET['m']=='attendance'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=attendance">
                              <i class="fas fa-fw fa-calendar"></i>
                    <span>Attendance</span></a>
            </li>
			
			<li class="nav-item <?php if($_GET['m']=='reports'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=reports">
                              <i class="fas fa-fw fa-table"></i>
                    <span>Reports</span></a>
            </li>
