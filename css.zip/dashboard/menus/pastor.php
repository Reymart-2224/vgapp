 	

<li class="nav-item <?php if($_GET['m']=='leaders'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=leaders">
                              <i class="fas fa-fw fa-users"></i>
                    <span>VG Leaders</span></a>
            </li>
			
			   <li class="nav-item <?php if($_GET['m']=='members'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=members">
                              <i class="fas fa-fw fa-users"></i>
                    <span>VG Members</span></a>
            </li>
			 <li class="nav-item <?php if($_GET['m']=='vg'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=vg">
                              <i class="fas fa-fw fa-pray"></i>
                    <span>My VG's</span></a>
            </li>
			   <li class="nav-item <?php if($_GET['m']=='referrals'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=referrals">
                              <i class="fas fa-fw fa-exchange-alt"></i>
                    <span>Referrals</span></a>
            </li>
			 <li class="nav-item <?php if($_GET['m']=='attendance'){ echo 'active'; }?>">
                   <a class="nav-link" href="?m=attendance">
                              <i class="fas fa-fw fa-calendar"></i>
                    <span>Attendance</span></a>
            </li>
			
